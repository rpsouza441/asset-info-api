from flask_caching import Cache

def get_from_cache(cache, key):
    """
    Busca um item do cache.
    """
    return cache.get(key)

def set_to_cache(cache, key, value):
    """
    Armazena um item no cache.
    """
    cache.set(key, value)
