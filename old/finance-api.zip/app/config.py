from fastapi_cache import FastAPICache
from fastapi_cache.backends.redis import RedisBackend
from redis import asyncio as aioredis

def create_cache():
    """
    Configura o cache para FastAPI utilizando Redis.
    """
    redis = aioredis.from_url("redis://ticker-api-redis:6379", encoding="utf-8", decode_responses=True)
    FastAPICache.init(RedisBackend(redis))
    return redis
