from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from app.config import create_cache
from app.cache_service import get_from_cache, set_to_cache
from app.yahoo_service import fetch_ticker_data
from app.fii_verification import verificar_fundo_investimento

app = FastAPI(
    title="Ticker API",
    description="API para verificar se um ativo é um fundo de investimento imobiliário (FII).",
    version="1.0.0",
)

# Inicializa o cache
cache = create_cache()

# Modelos de entrada e saída
class TickerRequest(BaseModel):
    ticker: str

class TickerResponse(BaseModel):
    ticker: str
    longName: Optional[str]
    quoteType: Optional[str]
    fii: Optional[bool]

class TickersBatchRequest(BaseModel):
    tickers: List[str]

class TickerBatchResponse(BaseModel):
    ticker: str
    longName: Optional[str]
    quoteType: Optional[str]
    fii: Optional[bool]
    error: Optional[str] = None

# Endpoint para verificar um único ticker
@app.post("/fii-check", response_model=TickerResponse)
async def check_fii(request: TickerRequest):
    ticker = request.ticker.strip().upper()
    cache_key = f"fii-check:{ticker}"
    cached_result = get_from_cache(cache, cache_key)

    if cached_result:
        return cached_result

    try:
        info = fetch_ticker_data(ticker)
        if not info or "quoteType" not in info:
            raise HTTPException(status_code=404, detail=f"No valid data found for ticker {ticker}")
        is_fii = verificar_fundo_investimento(info)
        result = {
            "ticker": ticker,
            "longName": info.get("longName"),
            "quoteType": info.get("quoteType"),
            "fii": is_fii,
        }
        set_to_cache(cache, cache_key, result)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Endpoint para verificar múltiplos tickers
@app.post("/fii-check-batch", response_model=List[TickerBatchResponse])
async def check_fii_batch(request: TickersBatchRequest):
    results = []
    for ticker in request.tickers:
        ticker = ticker.strip().upper()
        cache_key = f"fii-check:{ticker}"
        cached_result = get_from_cache(cache, cache_key)

        if cached_result:
            results.append(cached_result)
            continue

        try:
            info = fetch_ticker_data(ticker)
            if not info or "quoteType" not in info:
                results.append({"ticker": ticker, "error": "No valid data found"})
                continue
            is_fii = verificar_fundo_investimento(info)
            result = {
                "ticker": ticker,
                "longName": info.get("longName"),
                "quoteType": info.get("quoteType"),
                "fii": is_fii,
            }
            set_to_cache(cache, cache_key, result)
            results.append(result)
        except Exception as e:
            results.append({"ticker": ticker, "error": str(e)})
    return results
#aut