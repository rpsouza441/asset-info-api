from datetime import datetime
from app.tokens import tokens  # Importa os tokens

def validate_token(token):
    """
    Valida o token recebido.
    """
    for entry in tokens:
        if entry["token"] == token and entry["expiry"] >= datetime.now():
            return True
    return False
