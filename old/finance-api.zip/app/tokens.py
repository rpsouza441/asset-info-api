import datetime

tokens = [
    {"name": "rodrigo", "token": "TQXPjrLd8xkQHm66ioF4EL8dWw", "expiry": datetime.datetime(2125, 1, 31)},
    {"name": "user2", "token": "evROp3jER9Ujeac0sTEdo7PoYw", "expiry": datetime.datetime(2030, 2, 28)},
]
